2:"$Sreact.fragment"
3:I[7121,[],""]
4:I[4581,[],""]
9:"static/chunks/500-fc3b64d9ff4a32a7.js"
a:"static/chunks/app/sign-in-error/page-d1557c93762d37ae.js"
b:I[8500,["500","$9","285","$a"],""]
c:I[484,[],"OutletBoundary"]
d:"$Sreact.suspense"
10:"ViewportBoundary"
11:I[484,[],"$10"]
12:"MetadataBoundary"
13:I[484,[],"$12"]
6:X
6:C
7:X
8:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$2","c",{"children":[["$","div",null,{"className":"wrap max-w-2xl py-12","children":[["$","h1",null,{"className":"text-3xl font-bold","children":"Sign-in could not be completed"}],["$","p",null,{"className":"mt-3 text-muted","children":"Return to IT Self-Service and open the service again to restart sign-in."}],["$","$Lb",null,{"href":"/","className":"button mt-5","children":"Back to IT Self-Service"}]]}],null,["$","$Lc",null,{"children":["$","$d",null,{"name":"Next.MetadataOutlet","children":"$@e"}]}]]}],"p":"$@f","v":null,"s":"$7"}}]]
1:[["children",{"s":"sign-in-error","h":64,"d":{"r":["$","$2","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]]}],"p":"$@5","v":"$6","s":"$7"},"c":"$Q8"}]]
0:{"t":{"t":{"s":"","h":16,"c":"$Q1"},"h":{"r":["$","$2","h",{"children":[null,["$","$L11",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L13",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$d",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"IT Self-Service | Regent College London"}],["$","meta","1",{"name":"description","content":"Regent College London IT support, software and password management."}]]}]}],null]}],null]}],"p":"$@14","v":null,"s":"$7"}},"a":"$@15","u":"$@16","b":"QM4zVbqowKwQM6F26LGrE"}
e:null
16:true
7:300
7:C
15:0
5:"$undefined"
14:"$undefined"
f:"$undefined"
