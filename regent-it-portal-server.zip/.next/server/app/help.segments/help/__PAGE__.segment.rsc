2:"$Sreact.fragment"
3:I[7121,[],""]
4:I[4581,[],""]
9:"static/chunks/500-fc3b64d9ff4a32a7.js"
a:"static/chunks/app/help/page-d1557c93762d37ae.js"
b:I[8500,["500","$9","728","$a"],""]
c:I[484,[],"OutletBoundary"]
d:"$Sreact.suspense"
10:"ViewportBoundary"
11:I[484,[],"$10"]
12:"MetadataBoundary"
13:I[484,[],"$12"]
6:X
6:C
7:X
8:[["children",{"s":"__PAGE__","h":160,"d":{"r":["$","$2","c",{"children":[["$","div",null,{"className":"wrap max-w-3xl py-10","children":[["$","$Lb",null,{"href":"/","className":"font-semibold text-accent hover:underline","children":"← Back to IT Self-Service"}],["$","h1",null,{"className":"my-5 text-4xl font-bold","children":"IT Help"}],["$","div",null,{"className":"panel space-y-6 p-6","children":[["$","section",null,{"id":"faqs","children":[["$","h2",null,{"className":"text-xl font-bold","children":"FAQs"}],["$","details",null,{"className":"mt-2","children":[["$","summary",null,{"className":"cursor-pointer font-medium","children":"How do I reset my password?"}],["$","p",null,{"className":"mt-1 text-muted","children":["Use ",["$","a",null,{"className":"underline","href":"https://passwordreset.microsoftonline.com/","target":"_blank","rel":"noopener noreferrer","children":"Microsoft Password Reset (new tab)"}]," and follow the verification steps."]}]]}],["$","details",null,{"className":"mt-2","children":[["$","summary",null,{"className":"cursor-pointer font-medium","children":"How do I raise an IT ticket?"}],["$","p",null,{"className":"mt-1 text-muted","children":["Open ",["$","$Lb",null,{"className":"underline","href":"/contact-it","children":"Contact IT"}]," and sign in with your college Microsoft account."]}]]}]]}],["$","section",null,{"id":"policies","children":[["$","h2",null,{"className":"text-xl font-bold","children":"IT Policies"}],["$","p",null,{"className":"text-muted","children":"Ask the IT Service Desk for the current security and acceptable use policies."}]]}],["$","section",null,{"id":"wifi","children":[["$","h2",null,{"className":"text-xl font-bold","children":"Wi-Fi Access"}],["$","p",null,{"className":"text-muted","children":"Contact the Service Desk for the network name and connection instructions for your campus."}]]}],["$","section",null,{"id":"printing","children":[["$","h2",null,{"className":"text-xl font-bold","children":"Printing Services"}],["$","p",null,{"className":"text-muted","children":"The Service Desk can help with printer access, setup, and print credit."}]]}],["$","section",null,{"children":[["$","h2",null,{"className":"text-xl font-bold","children":"IT Service Desk"}],["$","p",null,{"className":"text-muted","children":"Monday–Friday, 08:00–18:00"}],["$","a",null,{"className":"block underline","href":"mailto:itsupport@regentcollege.ac.uk","children":"itsupport@regentcollege.ac.uk"}],["$","a",null,{"className":"block underline","href":"tel:+442074877200","children":"+44 20 7487 7200"}]]}]]}]]}],null,["$","$Lc",null,{"children":["$","$d",null,{"name":"Next.MetadataOutlet","children":"$@e"}]}]]}],"p":"$@f","v":null,"s":"$7"}}]]
1:[["children",{"s":"help","h":64,"d":{"r":["$","$2","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]]}],"p":"$@5","v":"$6","s":"$7"},"c":"$Q8"}]]
0:{"t":{"t":{"s":"","h":16,"c":"$Q1"},"h":{"r":["$","$2","h",{"children":[null,["$","$L11",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L13",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$d",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"IT Help | Regent College London IT"}],["$","meta","1",{"name":"description","content":"Regent College London IT support, software and password management."}]]}]}],null]}],null]}],"p":"$@14","v":null,"s":"$7"}},"a":"$@15","u":"$@16","b":"QM4zVbqowKwQM6F26LGrE"}
e:null
16:true
7:300
7:C
15:0
5:"$undefined"
14:"$undefined"
f:"$undefined"
