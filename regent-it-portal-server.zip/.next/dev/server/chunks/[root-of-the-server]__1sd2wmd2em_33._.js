module.exports = [
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/runtime-reacts.external.js [external] (next/dist/server/runtime-reacts.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/server/runtime-reacts.external.js", () => require("next/dist/server/runtime-reacts.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/src/app/api/auth/start/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openid$2d$client$2f$build$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/openid-client/build/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$entra$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/entra.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/services.ts [app-route] (ecmascript)");
;
;
;
;
async function GET(request) {
    const service = request.nextUrl.searchParams.get("service");
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$services$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["isService"])(service)) return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"]("Unknown IT service", {
        status: 400
    });
    const unavailable = ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL(`/${service}?error=unavailable`, request.url));
    try {
        const settings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$entra$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["entraSettings"])();
        if (!settings) return unavailable();
        const config = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$entra$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["discoverEntra"])(settings);
        const verifier = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openid$2d$client$2f$build$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["randomPKCECodeVerifier"]();
        const state = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openid$2d$client$2f$build$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["randomState"]();
        const nonce = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openid$2d$client$2f$build$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["randomNonce"]();
        const target = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openid$2d$client$2f$build$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildAuthorizationUrl"](config, {
            redirect_uri: settings.callback.href,
            scope: "openid profile",
            code_challenge: await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openid$2d$client$2f$build$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["calculatePKCECodeChallenge"](verifier),
            code_challenge_method: "S256",
            state,
            nonce
        });
        const response = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].redirect(target);
        response.headers.set("Cache-Control", "no-store");
        response.cookies.set(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$entra$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["flowCookie"], JSON.stringify({
            verifier,
            state,
            nonce,
            service
        }), {
            httpOnly: true,
            secure: settings.app.protocol === "https:",
            sameSite: "lax",
            path: "/api/auth",
            maxAge: 600
        });
        return response;
    } catch  {
        return unavailable();
    }
}
}),
"[project]/src/lib/entra.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "discoverEntra",
    ()=>discoverEntra,
    "entraSettings",
    ()=>entraSettings,
    "flowCookie",
    ()=>flowCookie
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openid$2d$client$2f$build$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/openid-client/build/index.js [app-route] (ecmascript) <locals>");
;
const flowCookie = "regent-entra-flow";
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function entraSettings() {
    const tenant = process.env.ENTRA_TENANT_ID?.toLowerCase();
    const clientId = process.env.ENTRA_CLIENT_ID;
    const secret = process.env.ENTRA_CLIENT_SECRET;
    const appUrl = process.env.APP_URL;
    if (!tenant || !uuid.test(tenant) || !clientId || !uuid.test(clientId) || !secret || !appUrl) return null;
    const app = new URL(appUrl);
    const localHttp = app.protocol === "http:" && [
        "localhost",
        "127.0.0.1"
    ].includes(app.hostname);
    // if ((!localHttp && app.protocol !== "https:") || app.username || app.password || app.pathname !== "/" || app.search || app.hash) {
    //   throw new Error("APP_URL must be an HTTPS origin or a localhost HTTP origin.");
    // }
    return {
        app,
        tenant,
        clientId,
        secret,
        callback: new URL("/api/auth/callback", app)
    };
}
async function discoverEntra(settings) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openid$2d$client$2f$build$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["discovery"](new URL(`https://login.microsoftonline.com/${settings.tenant}/v2.0`), settings.clientId, settings.secret);
}
}),
"[project]/src/lib/services.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isService",
    ()=>isService,
    "protectedServices",
    ()=>protectedServices,
    "resetUrl",
    ()=>resetUrl,
    "resources",
    ()=>resources,
    "supportEmail",
    ()=>supportEmail,
    "supportHours",
    ()=>supportHours,
    "supportPhone",
    ()=>supportPhone,
    "tiles",
    ()=>tiles
]);
const resetUrl = "https://passwordreset.microsoftonline.com/";
const protectedServices = {
    "software-centre": {
        title: "Software Centre",
        url: "https://titchfieldrds.rtc.uk.net/RDWeb/Pages/en-US/login.aspx?ReturnUrl=/RDWeb/Pages/en-US/Default.aspx"
    },
    "contact-it": {
        title: "Contact IT",
        url: "https://regentgroup.freshservice.com/a/tickets/new"
    },
    "my-tickets": {
        title: "My Tickets",
        url: "https://regentgroup.freshservice.com/support/tickets"
    }
};
function isService(value) {
    return !!value && Object.hasOwn(protectedServices, value);
}
const supportEmail = "itsupport@regentcollege.ac.uk";
const supportPhone = "+44 20 7487 7200";
const supportHours = "Monday–Friday, 08:00–18:00";
const tiles = [
    {
        title: "Password Reset",
        icon: "key",
        tone: "pink",
        description: "Reset your Microsoft 365 password securely using Microsoft’s self-service portal.",
        action: "Reset Password",
        href: resetUrl,
        public: true
    },
    {
        title: "Software Centre",
        icon: "laptop",
        tone: "lilac",
        description: "Access approved college applications, software packages and licensed tools.",
        action: "Open Software Centre",
        href: "/software-centre",
        public: false
    },
    {
        title: "Contact IT",
        icon: "ticket",
        tone: "blue",
        description: "Submit a support request, report an issue, or request assistance from the IT Service Desk.",
        action: "Raise Ticket",
        href: "/contact-it",
        public: false
    }
];
const resources = [
    {
        title: "Account & Security",
        icon: "lock",
        items: [
            {
                title: "Microsoft 365",
                icon: "microsoft",
                description: "Outlook, Teams, OneDrive and Office online",
                href: "https://www.microsoft365.com/"
            },
            {
                title: "Set Up MFA",
                icon: "shield",
                description: "Register or manage your multi-factor authentication",
                href: "https://mysignins.microsoft.com/security-info"
            },
            {
                title: "Change Password",
                icon: "lock",
                description: "Update your college account password",
                href: "https://myaccount.microsoft.com/"
            }
        ]
    },
    {
        title: "Support Resources",
        icon: "book",
        items: [
            {
                title: "Knowledge Base",
                icon: "shield",
                description: "Step-by-step guides and troubleshooting",
                href: "https://regentgroup.freshservice.com/support/solutions"
            },
            {
                title: "FAQs",
                icon: "help",
                description: "Find answers to common questions",
                href: "/help#faqs"
            },
            {
                title: "IT Policies",
                icon: "file",
                description: "Request current IT policies from the Service Desk",
                href: "/help#policies"
            }
        ]
    },
    {
        title: "Requests & Access",
        icon: "users",
        items: [
            {
                title: "My Tickets",
                icon: "list",
                description: "Track requests you’ve already raised",
                href: "/my-tickets"
            },
            {
                title: "Wi-Fi Access",
                icon: "wifi",
                description: "Connect your devices on campus",
                href: "/help#wifi"
            },
            {
                title: "Printing Services",
                icon: "printer",
                description: "Get help with campus printing and print credit",
                href: "/help#printing"
            }
        ]
    }
];
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__1sd2wmd2em_33._.js.map