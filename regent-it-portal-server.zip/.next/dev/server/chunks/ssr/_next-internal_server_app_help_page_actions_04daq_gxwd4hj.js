module.exports = [
"[project]/.next-internal/server/app/help/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_help_page_actions_04daq_gxwd4hj.js.map