var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/start/route.js")
R.c("server/chunks/node_modules_12qd1ebo2mrzl._.js")
R.c("server/chunks/[root-of-the-server]__1sd2wmd2em_33._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_start_route_actions_0jwdegqn7lbr-.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/start/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/start/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
