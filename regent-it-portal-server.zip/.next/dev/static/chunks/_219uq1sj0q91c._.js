(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_dist_0yp262t-r2o-y._.js","static/chunks/src_app_globals_162hn9oqc8uss.css","static/chunks/_0vv9kb7kay8t9._.js"],
    source: "entry"
});
